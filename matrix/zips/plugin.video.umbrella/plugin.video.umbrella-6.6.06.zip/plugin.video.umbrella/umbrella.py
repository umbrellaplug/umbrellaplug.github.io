# -*- coding: utf-8 -*-
"""
	Umbrella Add-on
"""

from sys import argv
from resources.lib.modules import router

if __name__ == '__main__':
	router.router(argv[2])